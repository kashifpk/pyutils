from distutils.core import setup
setup(name='pyutils',
      version='0.3',
       py_modules=['datetime_utils', 'db', 'debug', 'sorting', 'type_conversion', 'google_search', 'csv_parser', 'html_parser'],
)

